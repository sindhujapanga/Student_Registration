const graphql = require("graphql");
const express = require("express");
const {graphqlHTTP }= require("express-graphql");
const { GraphQLSchema } = graphql;
const { query } = require("./schemas/query");
const { mutation } = require("./schemas/mutation");
const { db } = require("./db")
const cors = require('cors')



const schema = new GraphQLSchema({
  query,
  mutation
});

var app = express();
//app.use(cors())
app.use(
  '/graphql',cors(),
  graphqlHTTP({
    schema: schema,
    graphiql: true
  })
);

app.listen(4000, () =>
  console.log('GraphQL server running on localhost:4000')
);
