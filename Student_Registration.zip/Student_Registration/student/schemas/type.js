const graphql = require("graphql");
const { GraphQLObjectType, GraphQLString } = graphql;

const UserType = new GraphQLObjectType({
  name: "User",
  type: "Query",
  fields: {
    id: { type: GraphQLString },
    username: { type: GraphQLString },
    password: { type: GraphQLString }
    
  }
});

const RegisterType = new GraphQLObjectType({
  name: "Register",
  type: "Query",
  fields: {
    id: { type: GraphQLString },
    firstname: { type: GraphQLString },
    lastname: { type: GraphQLString },
    gender: { type: GraphQLString },
    address: { type: GraphQLString },
    emailid: { type: GraphQLString },
   mobilenumber: { type: GraphQLString }
  }
});

exports.UserType = UserType;
exports.RegisterType = RegisterType;