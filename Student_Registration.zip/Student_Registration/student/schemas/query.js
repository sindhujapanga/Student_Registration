const { db } = require("../db");
const {  GraphQLList,GraphQLObjectType, GraphQLID } = require("graphql");
const { UserType, RegisterType } = require("./type");

const RootQuery = new GraphQLObjectType({
  name: "RootQueryType",
  type: "Query",
  fields: {
    register: {
      type: RegisterType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        const query = `SELECT * FROM register WHERE id=$1`;
        const values = [args.id];

        return db
          .one(query, values)
          .then(res => res)
          .catch(err => err);
      }
    },
    getuser: {
      type: UserType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        const query = `SELECT * FROM users WHERE id=$1`;
        const values = [args.id];

        return db
          .one(query, values)
          .then(res => res)
          .catch(err => err);
      }
    },
    allUsers: {
      type:new GraphQLList( UserType),
      args: {
      },
      resolve(parentValue, args) {
        const query = `SELECT * FROM users`;
    
        return db
          .any(query, args)
          .then(res => res)
          .catch(err => err);
      }
    },
    allDetails: {
      type:new GraphQLList( RegisterType),
      args: {
      },
      resolve(parentValue, args) {
        const query = `SELECT * FROM register`;
    
        return db
          .any(query, args)
          .then(res => res)
          .catch(err => err);
      },
    }
  }
  
});

exports.query = RootQuery;