const graphql = require("graphql");
const db = require("../db").db;
const { GraphQLObjectType, GraphQLID, GraphQLString, GraphQLBoolean } = graphql;
const { RegisterType } = require("./type");

const RootMutation = new GraphQLObjectType({
  name: "RootMutationType",
  type: "Mutation",
  fields: {
    addRegister: {
      type: RegisterType,
      args: {
        //Id: { type: GraphQLID },
        firstname: { type: GraphQLString },
    lastname: { type: GraphQLString },
    gender: { type: GraphQLString },
    address: { type: GraphQLString },
    emailid: { type: GraphQLString },
   mobilenumber: { type: GraphQLString }
      },
      resolve(parentValue, args) {
        const query = `INSERT INTO register(firstname, lastname,gender, address,emailid,mobilenumber) VALUES ($1, $2, $3, $4, $5, $6) RETURNING firstname`;
        const values = [
          //args.Id,
            args.firstname,
            args.lastname,
            args.gender,
            args.address,
            args.emailid,
            args.mobilenumber,

         
        ];

        return db
          .one(query, values)
          .then(res => res)
          .catch(err => err);
      }
    }
  }
});

exports.mutation = RootMutation;
