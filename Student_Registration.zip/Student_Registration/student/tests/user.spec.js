const app = require("../server");
const supertest = require("supertest");
const request = supertest(app);
const EasyGraphQLTester = require('easygraphql-tester')

/*it("Testing to see if Jest works", () => {
    expect(1).toBe(1);
  });
*/

let baseURL = supertest("http://localhost:4000/graphql");
let list_users = `{
    allUsers
    {
        id
        username
        password
    }
  }
  `;
describe("Get Request", () => {
    let resp;
    it("it should display all the users ", async () => {
        resp = await baseURL
            .get(list_users);

        await console.log(resp.body);

    });
});

let get_user = `{
    getuser(id:1)
    {
        id
        username
        password
    }
  }
  `;
describe("Get Request", () => {
    let get_resp;
    it(" displays a particular user ", async () => {
        get_resp = await baseURL
            .get(get_user)

        await console.log(get_resp.body);

    });
});


let get_registeredusers = `{
    register(id:1)
    {
      firstname
      lastname
      gender
      address
      emailid
      mobilenumber
      
    }
  }
  `;
describe("Get Request", () => {
    let get_resp;
    it("displays a registered user ", async () => {
        get_resp = await baseURL
            .get(get_registeredusers)

        await console.log(get_resp.body);

    });
});


let list_details = `{
  allDetails
  {
    firstname
    lastname
    gender
    address
    emailid
    mobilenumber
  }
}
`;
describe("Get Request", () => {
  let resp;
  it("it should display all the registered users", async () => {
      resp = await baseURL
          .get(list_details);

      await console.log(resp.body);

  });
});


let Regsitered_users = `{
    addRegister() {
        firstname
        lastname
        gender
        address
        emailid
        mobilenumber
      
    }
  }
  `;
describe("POST Request",  () => {
  let post_resp;
  it("adding  a user ", async () => {
    post_resp = await baseURL
      .post(Regsitered_users);
    await console.log(post_resp.body);
    
  });
});
