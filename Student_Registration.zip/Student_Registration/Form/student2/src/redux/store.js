import {createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import logger from 'redux-logger';
import reducer from './reducers/loginreducer';
//import reducer from './reducers/registerreducer';
const store = createStore(reducer, {},applyMiddleware(thunk, logger));
export default store;
