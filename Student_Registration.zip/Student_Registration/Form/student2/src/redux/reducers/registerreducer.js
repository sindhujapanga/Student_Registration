
const REGISTER__REQUESTED = 'REGISTER__REQUESTED';
const REGISTER__SUCCEEDED = 'REGISTER__SUCCEEDED';
const REGISTER__FAILED = 'REGISTER__FAILED';


function setRegisterRequested(isRegisterRequested) {
    return {
        type:  REGISTER__REQUESTED,
       isRegisterRequested
    };
}


function setRegisterSucceded(isRegisterSucceded) {
    return {
        type: REGISTER__SUCCEEDED,
        isRegisterSucceded
    };
}


function setRegisterFailed(registerFailed) {
    return {
        type: REGISTER__FAILED,
        registerFailed
    };
}


export const initialState = { // Exporting it for test purposes
    isRegisterRequeste: false,
    isRegisterSucceded: false,
    registerFailed: null
  };


export function register(firstname,lastname,gender,address,emailid,mobilenumber) {
    return dispatch => {
        dispatch(setRegisterRequested(true));
        dispatch(setRegisterSucceded(false));
        dispatch(setRegisterFailed(null));

        sendRegisterRequest(firstname,lastname,gender,address,emailid,mobilenumber)
            .then(success => {
                dispatch(setRegisterRequested(false));
                dispatch(setRegisterSucceded(true));
            })
            .catch(err => {
                dispatch(setRegisterRequested(false));
                dispatch(setRegisterFailed(err));
            });
    }
}
export default function reducer(state =initialState, action) {
    switch (action.type) {
        case REGISTER__SUCCEEDED:
            return Object.assign({
                ...state,
                isRegisterSucceded: action.isRegisterSucceded
            });
        case REGISTER__REQUESTED:
            return {
                ...state,
                isRegisterRequested: action.isRegisterRequested
            };
        case REGISTER__FAILED:
            return {
                ...state,
                registerFailed: action.registerFailed
            };

            default : return state;
    }
}

function sendRegisterRequest(firstname,lastname,gender,address,emailid,mobilenumber) {
    return new Promise((resolve, reject) => {
        setTimeout(()=>{
            if ((firstname=== register.firstname && lastname=== register.lastname && gender=== register.gender && address=== register.addres && emailid=== register.emailid && mobilenumber===  register.mobilenumber)){
                return resolve(true);
            }
            else {
                return reject(new Error('fill all the details'));
            }

        },1000);
       

    });
}