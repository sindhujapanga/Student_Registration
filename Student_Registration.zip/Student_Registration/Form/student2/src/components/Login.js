import axios from 'axios'
import React, { Component } from 'react'
import {connect } from 'react-redux'
import {login} from '../redux/reducers/loginreducer';
//import mapStateToProps from 'mapStateToProps'

class Login extends Component {
    constructor(props){
        super()
        this.state={

        };
       
        this.handleSubmit=this.handleSubmit.bind(this)
    }

    userhandler=(event)=>{
        this.setState({
            username: event.target.value
        })
    }
   passwordhandler=(event)=>{
       this.setState({
            password: event.target.value
        })
    }


    handleSubmit(data)
    {
        //alert(`Login successful`)
       
        //event.preventDefault();
       console.log(this.state);
       let {username, password}=this.state;
        this.props.login(username, password);
       /* this.setState({
          
            username : data.username,
            password : data.password
        });*/
    axios.get('http://localhost:4000/graphql')
    	.then(res => console.log(res.data));

    }

   
  
    render() {
        //let {username, password}=this.state;
        let{isLoginPending,isLoginSuccess,loginError}=this.props;
        return (
            <div className="container pt-5">
                <div className="row">
                    <div className="col"></div>
                    <div className="col-sm-4">
                        <div className="card">
                            <div className="card-header"><h4>Login</h4></div>
                            <div className="card-body">
                                <form onSubmit={this.handleSubmit}>
                                    <div className="form-group">
                                        <div className="row">

                                            <div className='col'>
                                                <input type="text" className="form-control" placeholder="Username"  value={this.props.username} onChange={this.userhandler} /></div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="row">

                                            <div className='col'>
                                                <input type="password" className="form-control" placeholder="password"   value={this.props.password} onChange={this.passwordhandler}/></div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <div className="custom-control custom-checkbox">
                                                    <input type="checkbox" className="custom-control-input" id="customCheck1" />
                                                    <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                                                </div>
                                            </div>
                                            </div>
                                            </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col">
                                                <button onClick={this.handleSubmit} className=" float-right"> <a href="/Home">Login</a></button>
                                          
                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-6"></div>
                                            <div className="col-md-6">
                                                <p className="forgot-password text-right">
                                                    Forgot <a href="#">password?</a></p></div>
                                        </div>



                                    </div>
                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col">
                                    <p className="forgot-password text-center">
                                        Don't have an account?<a href="/register">  Register</a>
                                    </p>
                                    </div>
                                    </div></div>

                                    {isLoginPending && <div> please wait</div>}
                                    {isLoginSuccess  && <div>welcome</div>}
                                    {loginError  && <div>{loginError.message}</div>}

                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="col"></div>
                </div>
            </div>

        );
    }
}

const mapStateToProps =(state)=>({
    
        isLoginPending: state.isLoginPending,
        isLoginSuccess: state.isLoginSuccess,
        loginError: state.loginError
});



const mapDispatchToProps =(dispatch)=>({

    
        login : (username, password)=> dispatch(login(username, password))
    });
 
export default connect(mapStateToProps, mapDispatchToProps)(Login);