

import React from 'react'

import gql from 'graphql-tag';
import { Query } from 'react-apollo';
import { Table } from 'reactstrap';


export const allUsers = gql`
{
  allDetails {
    id
   firstname
   lastname
   gender
   address
   emailid
   mobilenumber
  }
}

`;
export default () => (
  <Query query={allUsers}>
    
    {({ loading, data }) => !loading && (
      <Table className="table-bordered">
        <thead>
          <tr>
            <th>firstname</th> 
            <th>lastname</th> 
            <th>gender</th>
            <th>address</th>
            <th> emailid</th>
            <th>mobilenumber</th>
          </tr>
        </thead>
        <tbody>
          {data.allDetails.map(allDetails => (
            <tr key={allDetails.id}>

            <td>{allDetails.firstname}</td>
            <td>{allDetails.lastname}</td>
            <td>{allDetails.gender}</td>
            <td>{allDetails.address}</td>
            <td>{allDetails.emailid}</td>
            <td>{allDetails.mobilenumber}</td>
          </tr>
          ))}
        </tbody>
      </Table>
    
      
    )}
  </Query>
 
 
);

          



 



