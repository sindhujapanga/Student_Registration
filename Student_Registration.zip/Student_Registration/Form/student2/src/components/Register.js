import React, { Component } from 'react'
import { Mutation } from 'react-apollo';
//import PropTypes from 'prop-types'
//import axios from 'axios'
import { connect } from 'react-redux'
import { register } from '../redux/reducers/registerreducer';


import { gql } from "apollo-boost";

const ADD_USER = gql`
mutation addRegister($firstname : String!,$lastname: String!, $gender: String!, $address:String!, $emailid:String!, $mobilenumber:String!) {
    addRegister(firstname:$firstname, lastname: $lastname,gender: $gender,address: $address,emailid: $emailid,mobilenumber: $mobilenumber){ 
    firstname
    }
 }
 ` ;

// const [addRegister, { loading, error }] = useMutation(INSERT_TODO);
class Register extends Component {

    constructor(props) {
        super()
        this.state = {
            /* firstname:"",
              lastname:"",
             
              gender:"",
              address:"",
                     
             
              emailid:"",
              mobilenumber:"",*/

        }

        this.handleSubmit = this.handleSubmit.bind(this)
    }
    firsthandler = (event) => {
        this.setState({
            firstname: event.target.value
        })
    }
    lasthandler = (event) => {
        this.setState({
            lastname: event.target.value
        })
    }

    genderhandler = (event) => {
        this.setState({
            gender: event.target.value
        })
    }

    addresshandler = (event) => {
        this.setState({
            address: event.target.value
        })
    }



    emailhandler = (event) => {
        this.setState({
            emailid: event.target.value
        })
    }
    mobilehandler = (event) => {
        this.setState({
            mobilenumber: event.target.value
        })
    }



    handleSubmit = (event) => {
        alert(` Registered successfully`)
        console.log(this.state);
        event.preventDefault();
        // console.log(this.state);
        let { firstname, lastname, gender, address, emailid, mobilenumber } = this.state;
        this.props.register(firstname, lastname, gender, address, emailid, mobilenumber);
        /*const user = {
            firstname: this.state.firstname,
            lastname : this.state.lastname,
            gender: this.state.gender,
            address : this.state.address,
            emailid: this.state.emailid,
            mobilenumber: this.state.mobilenumber
        	
        }*/

        /*axios.post('http://localhost:4000/graphql')
        .then(res => console.log(res.event));*/
        /*axios({
             url: 'http://localhost:4000/graphql',
              method: 'post',
              data: {
               query: `mutation{
                addRegister( firstname: "${firstname}",lastname: "${lastname}",gender: "${gender}",address:"${address}",emailid:"${emailid}",mobilenumber:"${mobilenumber}"){
                 firstname
                }
               }`
              }
             })
              .then(res => {
               console.log(res.data);
              })
              .catch(err => {
               console.log(err.message);
              });*/

            

    }


    render() {
       // const { firstname, lastname, gender, address, emailid, mobilenumber } = this.state
        let { isRegisterRequested, isRegisterSucceded, registerFailed } = this.props;
        return (


            <div className="container pt-5 ">
                <div className="row">
                    <div className="col"></div>
                    <div className="col-sm-6">
                        <div className="card ">
                            <div className="card-header"><h4>  REGISTRATION FORM</h4></div>
                            <div className="card-body">
                                <form onSubmit={this.handleSubmit} method="POST">
                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-4">
                                                <label> First name :</label></div>
                                            <div className='col-md-8'>
                                                <input type="text" value={this.props.firstname} onChange={this.firsthandler} className="form-control" placeholder="firstname" /></div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-4">
                                                <label> Last name :</label></div>
                                            <div className='col-md-8'>
                                                <input type="text" value={this.props.lastname} onChange={this.lasthandler} className="form-control" placeholder="lastname" /></div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-4">
                                                <label>Gender :</label></div>
                                            <div className="col-md-4">
                                                <div className="form-check">
                                                    <input type="radio" onChange={this.genderhandler} name="gender" id="gender" value="male" />
                                                    <label htmlFor="gender">Male</label>
                                                </div>
                                            </div>
                                            <div className="col-md-4">
                                                <div className="form-check">
                                                    <input type="radio" onChange={this.genderhandler} name="gender" id="gender" value="female" />
                                                    <label htmlFor="gender">Female</label>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-4">
                                                <label>Address :</label></div>
                                            <div className='col-md-8'>
                                                <textarea className="form-control" value={this.props.address} onChange={this.addresshandler}></textarea></div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-4">
                                                <label> Email Id :</label></div>
                                            <div className='col-md-8'>
                                                <input type="email" className="form-control" value={this.props.emailid} onChange={this.emailhandler} /></div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col-md-4">
                                                <label> Mobile Number :</label></div>
                                            <div className='col-md-8'>
                                                <input type="tel" className="form-control" value={this.props.mobilenumber} onChange={this.mobilehandler} /></div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <div className="row">
                                            <div className="col">
                                                <Mutation mutation={ADD_USER} variables={{
                                                    
                                                    firstname: this.state.firstname,
                                                    lastname: this.state.lastname,
                                                    gender: this.state.gender,
                                                    address: this.state.address,
                                                    emailid: this.state.emailid,
                                                    mobilenumber: this.state.mobilenumber
                                                }}>
                                             {addRegister => (<button onClick={addRegister}>Register</button>)}
                                                </Mutation>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <a href="/">Already Registered? Login </a>
                                    </div>

                                    {isRegisterRequested && <div> please wait</div>}
                                    {isRegisterSucceded && <div>welcome</div>}
                                    {registerFailed && <div>{registerFailed.message}</div>}

                                </form>
                            </div>
                        </div>



                    </div>
                    <div className="col"></div>
                </div>

            </div>


        )
    }
}
const mapStateToProps = (state) => ({

    isRegisterRequested: state.isRegisterRequested,
    isRegisterSucceded: state.isRegisterSucceded,
    registerFailed: state.registerFailed
});



const mapDispatchToProps = (dispatch) => ({


    register: (firstname, lastname, gender, address, emailid, mobilenumber) => dispatch(register(firstname, lastname, gender, address, emailid, mobilenumber))
});

export default connect(mapStateToProps, mapDispatchToProps)(Register);

