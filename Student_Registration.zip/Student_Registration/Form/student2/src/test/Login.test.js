import React from 'react'

import Login from '../components/Login'
import { mount, shallow} from 'enzyme'
import {Provider} from 'react-redux'
import configureStore from 'redux-mock-store';

let store;
let wrapper;
const props={
}
const mockStore = configureStore();
describe('Login Component', () => {
 
  beforeEach(() => {
 store= mockStore(props)
  wrapper = mount(<Provider store={store}><Login {...props}/></Provider>)
  })

  describe('When the form is submitted', () => {
    it('should call the mock login function', () => {
    wrapper.simulate( 'submit', {preventDefault() {}} )
   
    })
    })

    it('should be called with the email and password in the state as arguments', () => {
      // fill in email field with blah@gmail.com
      wrapper.simulate('change',{target: {name: 'username', value: 'abc'}})

       wrapper.simulate('change', {target: {name: 'password', value: '123'}})

       wrapper.simulate("click", { preventDefault: () => {} })
       expect(wrapper).toMatchSnapshot();
       
       

    
      })
})

