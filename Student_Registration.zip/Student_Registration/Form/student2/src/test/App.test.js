

import React from 'react';
import ReactDOM from 'react-dom';
import { mount } from 'enzyme';
import { MemoryRouter } from 'react-router';
import {Provider} from 'react-redux';
import configureStore from 'redux-mock-store';
import Home from '../components/Home'
import Register from '../components/Register'
import Login from '../components/Login';
import App from '../App';


const mockStore = configureStore();
const store = mockStore();
jest.mock('firebase/app');

test('invalid path should redirect to 404', () => {
  const wrapper = mount(
    <MemoryRouter initialEntries={[ '/' ]}>
      <Provider store={store}>
      <App/>
      </Provider>
    </MemoryRouter>
  
  );
  expect(wrapper.find(<Login/>)).toHaveLength(0);
  expect(wrapper.contains(<Register/>)).toBe.true;
});

test('valid path should not redirect to 404', () => {
  const wrapper = mount(
    <MemoryRouter initialEntries={[ '/Register' ]}>
      <Provider store={store}>
      <App/>
      </Provider>
    </MemoryRouter>
  );
  expect(wrapper.contains(<Login/>)).toBe.true;
  expect(wrapper.find(<Register/>)).toHaveLength(0);
});


