import React from 'react';
import renderer from 'react-test-renderer';


import { login } from '../redux/reducers/loginreducer';
 


import {initialState} from '../redux/reducers/loginreducer'

describe('todos reducer', () => {
  it('should return the initial state', () => {
    expect(login(undefined, {})).toMatchSnapshot()
  })

    
  it('should handle login pending action', () => {
    expect(
      login(initialState,
      {
        type: 'LOGIN_PENDING',
        payload:{
            isLoginPending:'loginPending'
          }
      })
    ).toBe.true
  })

  it('should handle success login', () => {
    expect(
      login(initialState,
      {
        type: 'LOGIN_SUCCESS',
        payload:{
            isLoginSuccess:'loginSuccess'
          }
      })
    ).toBe.true
  })

  
  it('should handle error', () => {
    expect(
      login(initialState,
      {
        type: 'LOGIN_ERROR',
        payload:{
            loginError:'loginError'
          }
      })
    ).toMatchSnapshot()
  })
})