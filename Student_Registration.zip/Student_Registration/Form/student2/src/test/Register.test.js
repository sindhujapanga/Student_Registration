import React from 'react'
import Register from '../components/Register'
import {mount} from 'enzyme'
import {Provider} from 'react-redux'
import { ApolloProvider } from 'react-apollo';
import configureStore from 'redux-mock-store';
import ApolloClient from 'apollo-boost';

const mockStore = configureStore();
const store = mockStore();
const client = new ApolloClient({
    uri: 'http://localhost:4000/graphql'
  });
  
const props={
  
}

describe('<Register>', () => {
    it('has a register button', () => {
      const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);-
      expect(wrapper.contains(<button type="submit">Register</button>)).toBe.true;
    });
  
    it('has a firstname input field', () => {
      const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);
      expect(wrapper.contains(<input type="text" />)).toBe.true;
    });
  
    it('has a lastname input field', () => {
      const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);
      expect(wrapper.contains(<input type="text" />)).toBe.true;
    });
    it('has a gender input field', () => {
        const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);
        expect(wrapper.contains(<input type="radio" />)).toBe.true;
      });
      it('has a address input field', () => {
        const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);
        expect(wrapper.contains(<input type="textarea" />)).toBe.true;
      });
      it('has a emailid input field', () => {
        const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);
        expect(wrapper.contains(<input type="email" />)).toBe.true;
      });
      it('has a mobilenumber input field', () => {
        const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register {...props}/></ApolloProvider></Provider>);
        expect(wrapper.contains(<input type="tel" />)).toBe.true;
      });
     
  
   it('passes register information', () => {
      const firstname = 's', lastname='b',gender='f',address='h',emailid='d',mobilenumber='86'
      
      const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Register handleSubmit={state => {
        expect(state.firstname).toBe.Equal(firstname);
        expect(state.lastname).toBe.Equal(lastname);
        expect(state.gender).toBe.Equal(gender);
        expect(state.address).toBe.Equal(address);     
        expect(state.emailid).toBe.Equal(emailid);
        expect(state.mobilenumber).toBe.Equal(mobilenumber);

      }}/></ApolloProvider></Provider>);
     wrapper.setProps({firstname:'s', lastname:'b',gender:'f',address:'h',emailid:'d',mobilenumber:'86'});
     wrapper.simulate("click", { preventDefault: () => {} });
    // expect(wrapper).toMatchSnapshot();
     
     
    });
  });

  