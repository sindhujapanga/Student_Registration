import React from 'react';
import {mount, shallow} from 'enzyme'
import Home, { allUsers } from '../components/Home';
import {Provider} from 'react-redux'
import { ApolloProvider } from 'react-apollo';
import configureStore from 'redux-mock-store';
import ApolloClient from 'apollo-boost';

const mockStore = configureStore();
const store= mockStore();
//const client = mockStore();
const client = new ApolloClient({
    uri: 'http://localhost:4000/graphql'
  });
  

describe('test MyComponent', () => {
   
    const wrapper = mount(<Provider store={store}><ApolloProvider client={client}><Home /></ApolloProvider></Provider>);
  
    const table = wrapper.find('table');
    const row = table.find('tr')
    const data = table.find('td')

    it('table grid', () => {
        expect(allUsers.table).toMatchSnapshot();
        expect(row)
        expect(data)
    });
   
});