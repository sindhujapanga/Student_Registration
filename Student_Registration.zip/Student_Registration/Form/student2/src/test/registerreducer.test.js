import React from 'react';
import renderer from 'react-test-renderer';


import { register } from '../redux/reducers/registerreducer';
 


import {initialState} from '../redux/reducers/loginreducer'

describe('todos reducer', () => {
  it('should return the initial state', () => {
    expect(register(undefined, {})).toMatchSnapshot()
  })

  it('should handle TODO_REQUEST', () => {
    expect(
      register(initialState,
      {
        type: 'REGISTER SUCCEEDED',
        payload:{
          isRegisterSucceded:'registerSucceded'
      }
      })
    ).toMatchSnapshot()
  })
})